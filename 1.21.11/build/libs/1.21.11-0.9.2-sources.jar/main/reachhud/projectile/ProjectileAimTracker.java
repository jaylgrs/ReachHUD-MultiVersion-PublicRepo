package main.reachhud.projectile;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class ProjectileAimTracker {

    private static final double MAX_AIM_DISTANCE = 64.0;

    /*
     * Vanilla crossbow arrow projectile speed.
     */
    private static final double CROSSBOW_ARROW_SPEED = 3.15;

    /*
     * Firework rocket initial projectile speed.
     *
     * Firework rockets use their own projectile movement,
     * so they are simulated separately from arrows.
     */
    private static final double FIREWORK_SPEED = 1.6;

    /*
     * Vanilla Multishot spread.
     */
    private static final double MULTISHOT_SPREAD_DEGREES = 10.0;

    private static class_1297 currentTarget;
    private static boolean willHit;
    private static double targetDistance = -1.0;

    private ProjectileAimTracker() {
    }

    public static void update(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            clearState();
            return;
        }

        ProjectileWeaponState weaponState =
                ProjectileWeaponState.detect(client);

        if (!weaponState.isProjectileWeapon()) {
            clearState();
            return;
        }

        /*
         * A bow only has a projectile trajectory while it
         * is actually being drawn.
         */
        if (weaponState.isBow()
                && !weaponState.isUsingWeapon()) {
            clearState();
            return;
        }

        /*
         * A crossbow only has a projectile trajectory when
         * it already contains a loaded projectile.
         */
        if (weaponState.isCrossbow()
                && !weaponState.isLoaded()) {
            clearState();
            return;
        }

        class_1297 target =
                findAimedEntity(client);

        if (target == null) {
            clearState();
            return;
        }

        currentTarget = target;

        class_243 startPosition =
                client.field_1724.method_33571();

        class_243 direction =
                client.field_1724.method_5828(1.0F);

        class_238 targetBox =
                target.method_5829()
                        .method_1014(target.method_5871());

        /*
         * Firework Rocket uses completely separate
         * projectile physics.
         */
        if (weaponState.isFirework()) {
            willHit = simulateFirework(
                    startPosition,
                    direction,
                    targetBox
            );
        } else {
            double projectileSpeed =
                    getProjectileSpeed(weaponState);

            if (projectileSpeed <= 0.0) {
                clearState();
                return;
            }

            /*
             * Normal Arrow / Crossbow Arrow.
             */
            if (!weaponState.hasMultishot()) {
                willHit = simulateTrajectory(
                        startPosition,
                        direction,
                        projectileSpeed,
                        targetBox
                );
            } else {
                /*
                 * Multishot:
                 *
                 * Center
                 * -10 degrees
                 * +10 degrees
                 */
                willHit = simulateMultishot(
                        startPosition,
                        direction,
                        projectileSpeed,
                        targetBox
                );
            }
        }

        targetDistance =
                getDistanceToTarget(
                        startPosition,
                        target
                );
    }

    private static boolean simulateTrajectory(
            class_243 startPosition,
            class_243 direction,
            double projectileSpeed,
            class_238 targetBox
    ) {
        class_243 initialVelocity =
                direction.method_1021(projectileSpeed);

        ProjectilePhysics.TrajectoryResult result =
                ProjectilePhysics.simulate(
                        startPosition,
                        initialVelocity,
                        targetBox
                );

        return result.hit();
    }

    private static boolean simulateFirework(
            class_243 startPosition,
            class_243 direction,
            class_238 targetBox
    ) {
        class_243 initialVelocity =
                direction.method_1021(FIREWORK_SPEED);

        FireworkPhysics.TrajectoryResult result =
                FireworkPhysics.simulate(
                        startPosition,
                        initialVelocity,
                        targetBox
                );

        return result.hit();
    }

    private static boolean simulateMultishot(
            class_243 startPosition,
            class_243 direction,
            double projectileSpeed,
            class_238 targetBox
    ) {
        /*
         * Center projectile.
         */
        if (simulateTrajectory(
                startPosition,
                direction,
                projectileSpeed,
                targetBox
        )) {
            return true;
        }

        /*
         * Left projectile.
         */
        class_243 leftDirection =
                rotateAroundY(
                        direction,
                        -MULTISHOT_SPREAD_DEGREES
                );

        if (simulateTrajectory(
                startPosition,
                leftDirection,
                projectileSpeed,
                targetBox
        )) {
            return true;
        }

        /*
         * Right projectile.
         */
        class_243 rightDirection =
                rotateAroundY(
                        direction,
                        MULTISHOT_SPREAD_DEGREES
                );

        return simulateTrajectory(
                startPosition,
                rightDirection,
                projectileSpeed,
                targetBox
        );
    }

    private static class_243 rotateAroundY(
            class_243 direction,
            double degrees
    ) {
        double radians =
                Math.toRadians(degrees);

        double cos =
                Math.cos(radians);

        double sin =
                Math.sin(radians);

        double x =
                direction.field_1352 * cos
                        - direction.field_1350 * sin;

        double z =
                direction.field_1352 * sin
                        + direction.field_1350 * cos;

        return new class_243(
                x,
                direction.field_1351,
                z
        ).method_1029();
    }

    private static double getProjectileSpeed(
            ProjectileWeaponState weaponState
    ) {
        if (weaponState.isBow()) {
            return calculateBowVelocity(
                    weaponState.getDrawProgress()
            );
        }

        if (weaponState.isCrossbow()
                && weaponState.isArrow()) {
            return CROSSBOW_ARROW_SPEED;
        }

        return 0.0;
    }

    private static double calculateBowVelocity(
            float drawProgress
    ) {
        float power = drawProgress;

        power =
                (power * power + power * 2.0F)
                        / 3.0F;

        if (power > 1.0F) {
            power = 1.0F;
        }

        if (power < 0.1F) {
            return 0.0;
        }

        return power * 3.0;
    }

    private static double getDistanceToTarget(
            class_243 startPosition,
            class_1297 target
    ) {
        class_238 targetBox =
                target.method_5829()
                        .method_1014(target.method_5871());

        return startPosition.method_1022(
                targetBox.method_1005()
        );
    }

    private static class_1297 findAimedEntity(
            class_310 client
    ) {
        class_243 start =
                client.field_1724.method_33571();

        class_243 direction =
                client.field_1724.method_5828(1.0F);

        class_1297 closestEntity = null;
        double closestDistance =
                MAX_AIM_DISTANCE;

        class_238 searchBox =
                client.field_1724
                        .method_5829()
                        .method_1014(MAX_AIM_DISTANCE);

        for (class_1297 entity :
                client.field_1724.method_73183().method_8333(
                        client.field_1724,
                        searchBox,
                        entity -> entity.method_5863()
                                && entity.method_5805()
                                && entity != client.field_1724
                )) {

            class_238 entityBox =
                    entity.method_5829()
                            .method_1014(entity.method_5871());

            double distance =
                    findRayIntersection(
                            start,
                            direction,
                            entityBox
                    );

            if (distance >= 0
                    && distance < closestDistance) {

                closestDistance = distance;
                closestEntity = entity;
            }
        }

        return closestEntity;
    }

    private static double findRayIntersection(
            class_243 start,
            class_243 direction,
            class_238 box
    ) {
        class_243 end =
                start.method_1019(
                        direction.method_1021(
                                MAX_AIM_DISTANCE
                        )
                );

        java.util.Optional<class_243> hit =
                box.method_992(start, end);

        if (hit.isEmpty()) {
            return -1.0;
        }

        return start.method_1022(hit.get());
    }

    public static class_1297 getCurrentTarget() {
        return currentTarget;
    }

    public static boolean hasTarget() {
        return currentTarget != null;
    }

    public static boolean willHit() {
        return willHit;
    }

    public static double getTargetDistance() {
        return targetDistance;
    }

    public static void clearTarget() {
        clearState();
    }

    private static void clearState() {
        currentTarget = null;
        willHit = false;
        targetDistance = -1.0;
    }
}