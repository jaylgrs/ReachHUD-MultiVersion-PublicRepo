package main.reachhud;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ReachHUD {

	public static final String MOD_ID = "reachhud";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private ReachHUD() {
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}