package main.reachhud.input;

import main.reachhud.ReachHUD;
import main.reachhud.config.ReachHudConfig;
import main.reachhud.hud.ReachHudNotification;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ReachHudKeybind {

    private static final class_304.class_11900 REACHHUD_CATEGORY =
            class_304.class_11900.method_74698(
                    class_2960.method_60655(
                            ReachHUD.MOD_ID,
                            "reachhud"
                    )
            );

    private static class_304 toggleKey;

    private ReachHudKeybind() {
    }

    public static void register() {
        if (toggleKey != null) {
            return;
        }

        toggleKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.reachhud.toggle",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_RIGHT_CONTROL,
                        REACHHUD_CATEGORY
                )
        );
    }

    public static void update() {
        if (toggleKey == null) {
            return;
        }

        while (toggleKey.method_1436()) {
            boolean newState = !ReachHudConfig.isEnabled();

            ReachHudConfig.setEnabled(newState);

            ReachHudNotification.show(newState);
        }
    }

    public static boolean isEnabled() {
        return ReachHudConfig.isEnabled();
    }
}