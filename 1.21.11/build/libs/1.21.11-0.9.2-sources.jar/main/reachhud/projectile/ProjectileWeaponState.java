package main.reachhud.projectile;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class ProjectileWeaponState {

    private static final int BOW_FULL_DRAW_TICKS = 20;

    public enum WeaponType {
        NONE,
        BOW,
        CROSSBOW
    }

    public enum ProjectileType {
        NONE,
        ARROW,
        FIREWORK
    }

    private final WeaponType weaponType;
    private final ProjectileType projectileType;
    private final boolean usingWeapon;
    private final boolean loaded;
    private final int useTicks;
    private final float drawProgress;
    private final int multishotLevel;

    private ProjectileWeaponState(
            WeaponType weaponType,
            ProjectileType projectileType,
            boolean usingWeapon,
            boolean loaded,
            int useTicks,
            float drawProgress,
            int multishotLevel
    ) {
        this.weaponType = weaponType;
        this.projectileType = projectileType;
        this.usingWeapon = usingWeapon;
        this.loaded = loaded;
        this.useTicks = useTicks;
        this.drawProgress = drawProgress;
        this.multishotLevel = multishotLevel;
    }

    public static ProjectileWeaponState detect(class_310 client) {
        if (client.field_1724 == null) {
            return none();
        }

        class_1799 mainHand = client.field_1724.method_6047();
        class_1799 offHand = client.field_1724.method_6079();

        class_1799 weapon = findWeapon(mainHand, offHand);

        if (weapon.method_7960()) {
            return none();
        }

        boolean usingWeapon = client.field_1724.method_6115();

        if (weapon.method_31574(class_1802.field_8102)) {
            int useTicks = usingWeapon
                    ? client.field_1724.method_6048()
                    : 0;

            float drawProgress =
                    calculateBowDrawProgress(useTicks);

            return new ProjectileWeaponState(
                    WeaponType.BOW,
                    ProjectileType.ARROW,
                    usingWeapon,
                    false,
                    useTicks,
                    drawProgress,
                    0
            );
        }

        if (weapon.method_31574(class_1802.field_8399)) {
            boolean loaded = isCrossbowLoaded(weapon);
            int multishotLevel = getMultishotLevel(weapon);

            ProjectileType projectileType =
                    getCrossbowProjectileType(weapon);

            return new ProjectileWeaponState(
                    WeaponType.CROSSBOW,
                    projectileType,
                    usingWeapon,
                    loaded,
                    0,
                    0.0F,
                    multishotLevel
            );
        }

        return none();
    }

    private static boolean isCrossbowLoaded(class_1799 weapon) {
        var chargedProjectiles =
                weapon.method_58694(class_9334.field_49649);

        return chargedProjectiles != null
                && chargedProjectiles.method_57437().size() > 0;
    }

    private static ProjectileType getCrossbowProjectileType(
            class_1799 weapon
    ) {
        var chargedProjectiles =
                weapon.method_58694(class_9334.field_49649);

        if (chargedProjectiles == null
                || chargedProjectiles.method_57437().isEmpty()) {
            return ProjectileType.NONE;
        }

        class_1799 projectile =
                chargedProjectiles.method_57437().get(0);

        if (projectile.method_31574(class_1802.field_8639)) {
            return ProjectileType.FIREWORK;
        }

        if (projectile.method_31574(class_1802.field_8107)
                || projectile.method_31574(class_1802.field_8087)
                || projectile.method_31574(class_1802.field_8236)) {
            return ProjectileType.ARROW;
        }

        return ProjectileType.NONE;
    }

    private static int getMultishotLevel(class_1799 weapon) {
        class_9304 enchantments =
                weapon.method_58694(class_9334.field_49633);

        if (enchantments == null) {
            return 0;
        }

        for (var entry : enchantments.method_57539()) {
            class_6880<class_1887> enchantment =
                    entry.getKey();

            boolean isMultishot =
                    enchantment.method_40230()
                            .map(key ->
                                    key.toString()
                                            .equals(
                                                    "ResourceKey[minecraft:enchantment / minecraft:multishot]"
                                            )
                            )
                            .orElse(false);

            if (isMultishot) {
                return entry.getIntValue();
            }
        }

        return 0;
    }

    private static float calculateBowDrawProgress(int useTicks) {
        if (useTicks <= 0) {
            return 0.0F;
        }

        return Math.min(
                useTicks / (float) BOW_FULL_DRAW_TICKS,
                1.0F
        );
    }

    private static class_1799 findWeapon(
            class_1799 mainHand,
            class_1799 offHand
    ) {
        if (mainHand.method_31574(class_1802.field_8102)
                || mainHand.method_31574(class_1802.field_8399)) {
            return mainHand;
        }

        if (offHand.method_31574(class_1802.field_8102)
                || offHand.method_31574(class_1802.field_8399)) {
            return offHand;
        }

        return class_1799.field_8037;
    }

    private static ProjectileWeaponState none() {
        return new ProjectileWeaponState(
                WeaponType.NONE,
                ProjectileType.NONE,
                false,
                false,
                0,
                0.0F,
                0
        );
    }

    public WeaponType getWeaponType() {
        return weaponType;
    }

    public ProjectileType getProjectileType() {
        return projectileType;
    }

    public boolean isUsingWeapon() {
        return usingWeapon;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public int getUseTicks() {
        return useTicks;
    }

    public float getDrawProgress() {
        return drawProgress;
    }

    public int getMultishotLevel() {
        return multishotLevel;
    }

    public boolean hasMultishot() {
        return multishotLevel > 0;
    }

    public boolean isBow() {
        return weaponType == WeaponType.BOW;
    }

    public boolean isCrossbow() {
        return weaponType == WeaponType.CROSSBOW;
    }

    public boolean isArrow() {
        return projectileType == ProjectileType.ARROW;
    }

    public boolean isFirework() {
        return projectileType == ProjectileType.FIREWORK;
    }

    public boolean isProjectileWeapon() {
        return weaponType != WeaponType.NONE;
    }
}