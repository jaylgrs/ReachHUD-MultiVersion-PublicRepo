package main.reachhud.reach;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class ReachCalculator {

    private ReachCalculator() {
    }

    public static double getDistanceTo(class_1297 entity) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || entity == null) {
            return -1.0;
        }

        class_243 eyePosition = client.field_1724.method_33571();

        class_238 targetBox = entity.method_5829();

        return Math.sqrt(targetBox.method_49271(eyePosition));
    }

    public static double getPlayerReach() {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null) {
            return -1.0;
        }

        return client.field_1724.method_45325(
                net.minecraft.class_5134.field_47759
        );
    }

    public static boolean isWithinReach(class_1297 entity) {
        double distance = getDistanceTo(entity);
        double reach = getPlayerReach();

        if (distance < 0 || reach < 0) {
            return false;
        }

        return distance <= reach;
    }
}