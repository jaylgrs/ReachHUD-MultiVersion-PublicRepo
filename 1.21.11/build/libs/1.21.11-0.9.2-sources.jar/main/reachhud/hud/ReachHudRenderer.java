package main.reachhud.hud;

import main.reachhud.ReachHUD;
import main.reachhud.input.ReachHudKeybind;
import main.reachhud.projectile.ProjectileAimTracker;
import main.reachhud.reach.ReachCalculator;
import main.reachhud.target.TargetTracker;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_1297;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class ReachHudRenderer {

    private static final double SMOOTH_SPEED = 0.25;
    private static final double FADE_SPEED = 0.18;

    private static class_1297 lastTarget;
    private static double displayedDistance = -1.0;

    private static String cachedMeleeTargetName = "";
    private static String cachedMeleeDistanceText = "";
    private static boolean cachedMeleeWithinReach;
    private static int cachedMeleeTargetColor = 0xFFFFFFFF;

    private static class_1297 lastProjectileTarget;
    private static double displayedProjectileDistance = -1.0;

    private static String cachedProjectileTargetName = "";
    private static String cachedProjectileDistanceText = "";
    private static boolean cachedProjectileWillHit;
    private static int cachedProjectileTargetColor = 0xFFFFFFFF;

    private static double hudAlpha = 0.0;

    private ReachHudRenderer() {
    }

    public static void register() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CROSSHAIR,
                ReachHUD.id("reach_hud"),
                ReachHudRenderer::render
        );
    }

    private static void render(
            class_332 graphics,
            class_9779 deltaTracker
    ) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || client.field_1690.field_1842) {
            resetSmoothing();
            return;
        }

        if (client.field_1755 != null) {
            resetSmoothing();
            return;
        }

        renderNotification(graphics, client);

        if (!ReachHudKeybind.isEnabled()) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetSmoothingValuesOnly();
            return;
        }

        if (ProjectileAimTracker.hasTarget()) {
            renderProjectileHud(graphics, client);
            return;
        }

        resetProjectileSmoothing();

        class_1297 target = TargetTracker.getCurrentTarget();

        if (target == null) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetMeleeSmoothingOnly();
            return;
        }

        double distance = ReachCalculator.getDistanceTo(target);
        double reach = ReachCalculator.getPlayerReach();

        if (distance < 0 || reach < 0) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetMeleeSmoothingOnly();
            return;
        }

        if (distance > reach + 3.0) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetMeleeSmoothingOnly();
            return;
        }

        boolean withinReach = distance <= reach;

        updateSmoothedDistance(target, distance);

        String targetName = target.method_5477().getString();
        String reachLabel = "Reach: ";
        String distanceText = String.format("%.2f", displayedDistance);

        int targetNameColor = getTargetNameColor(target);

        cachedMeleeTargetName = targetName;
        cachedMeleeDistanceText = distanceText;
        cachedMeleeWithinReach = withinReach;
        cachedMeleeTargetColor = targetNameColor;

        updateHudAlpha(true);

        renderMeleeHud(
                graphics,
                client,
                targetName,
                reachLabel,
                distanceText,
                withinReach,
                targetNameColor,
                hudAlpha
        );
    }

    private static void renderMeleeHud(
            class_332 graphics,
            class_310 client,
            String targetName,
            String reachLabel,
            String distanceText,
            boolean withinReach,
            int targetNameColor,
            double alpha
    ) {
        if (alpha <= 0.001) {
            return;
        }

        int targetNameWidth = client.field_1772.method_1727(targetName);
        int reachLabelWidth = client.field_1772.method_1727(reachLabel);
        int distanceWidth = client.field_1772.method_1727(distanceText);

        int reachTotalWidth = reachLabelWidth + distanceWidth;

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        int targetY = centerY + 11;
        int reachY = centerY + 23;

        int targetX = centerX - targetNameWidth / 2;
        int reachX = centerX - reachTotalWidth / 2;

        int distanceColor =
                withinReach
                        ? 0xFF55FF55
                        : 0xFFFF5555;

        int fadedTargetColor =
                applyAlpha(targetNameColor, alpha);

        int fadedDistanceColor =
                applyAlpha(distanceColor, alpha);

        int fadedLabelColor =
                applyAlpha(0xFFCCCCCC, alpha);

        int paddingHorizontal = 6;

        int boxX = reachX - paddingHorizontal;
        int boxY = reachY - 2;

        int boxWidth =
                reachTotalWidth + paddingHorizontal * 2;

        int boxHeight = 12;

        int backgroundColor =
                applyAlpha(0x99000000, alpha);

        drawRoundedBox(
                graphics,
                boxX,
                boxY,
                boxWidth,
                boxHeight,
                backgroundColor
        );

        int accentColor =
                withinReach
                        ? 0xFF55FF55
                        : 0xFFFF5555;

        accentColor = applyAlpha(accentColor, alpha);

        int accentX = boxX + 2;
        int accentY = boxY + boxHeight - 1;
        int accentWidth = boxWidth - 4;

        graphics.method_25294(
                accentX,
                accentY,
                accentX + accentWidth,
                accentY + 1,
                accentColor
        );

        int indicatorColor =
                applyAlpha(targetNameColor, alpha);

        int indicatorSize = 3;

        int indicatorX = targetX - 6;
        int indicatorY = targetY + 4;

        graphics.method_25294(
                indicatorX,
                indicatorY,
                indicatorX + indicatorSize,
                indicatorY + indicatorSize,
                indicatorColor
        );

        drawText(
                graphics,
                client,
                targetName,
                targetX,
                targetY,
                fadedTargetColor,
                alpha
        );

        drawText(
                graphics,
                client,
                reachLabel,
                reachX,
                reachY,
                fadedLabelColor,
                alpha
        );

        drawText(
                graphics,
                client,
                distanceText,
                reachX + reachLabelWidth,
                reachY,
                fadedDistanceColor,
                alpha
        );
    }

    private static void renderProjectileHud(
            class_332 graphics,
            class_310 client
    ) {
        class_1297 target =
                ProjectileAimTracker.getCurrentTarget();

        if (target == null) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetProjectileSmoothing();
            return;
        }

        double distance =
                ProjectileAimTracker.getTargetDistance();

        if (distance < 0) {
            updateHudAlpha(false);
            renderCachedHud(graphics, client);
            resetProjectileSmoothing();
            return;
        }

        boolean willHit =
                ProjectileAimTracker.willHit();

        updateSmoothedProjectileDistance(
                target,
                distance
        );

        String targetName =
                target.method_5477().getString();

        String aimLabel = "Aim: ";

        String distanceText =
                String.format(
                        "%.2f",
                        displayedProjectileDistance
                );

        int targetNameColor =
                getTargetNameColor(target);

        cachedProjectileTargetName = targetName;
        cachedProjectileDistanceText = distanceText;
        cachedProjectileWillHit = willHit;
        cachedProjectileTargetColor = targetNameColor;

        updateHudAlpha(true);

        renderProjectileHudContent(
                graphics,
                client,
                targetName,
                aimLabel,
                distanceText,
                willHit,
                targetNameColor,
                hudAlpha
        );
    }

    private static void renderProjectileHudContent(
            class_332 graphics,
            class_310 client,
            String targetName,
            String aimLabel,
            String distanceText,
            boolean willHit,
            int targetNameColor,
            double alpha
    ) {
        if (alpha <= 0.001) {
            return;
        }

        int targetNameWidth =
                client.field_1772.method_1727(targetName);

        int aimLabelWidth =
                client.field_1772.method_1727(aimLabel);

        int distanceWidth =
                client.field_1772.method_1727(distanceText);

        int aimTotalWidth =
                aimLabelWidth + distanceWidth;

        int screenWidth =
                client.method_22683().method_4486();

        int screenHeight =
                client.method_22683().method_4502();

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        int targetY = centerY + 11;
        int aimY = centerY + 23;

        int targetX =
                centerX - targetNameWidth / 2;

        int aimX =
                centerX - aimTotalWidth / 2;

        int distanceColor =
                willHit
                        ? 0xFF55FF55
                        : 0xFFFF5555;

        int fadedTargetColor =
                applyAlpha(targetNameColor, alpha);

        int fadedDistanceColor =
                applyAlpha(distanceColor, alpha);

        int fadedLabelColor =
                applyAlpha(0xFFCCCCCC, alpha);

        int paddingHorizontal = 6;

        int boxX = aimX - paddingHorizontal;
        int boxY = aimY - 2;

        int boxWidth =
                aimTotalWidth + paddingHorizontal * 2;

        int boxHeight = 12;

        int backgroundColor =
                applyAlpha(0x99000000, alpha);

        drawRoundedBox(
                graphics,
                boxX,
                boxY,
                boxWidth,
                boxHeight,
                backgroundColor
        );

        int accentColor =
                willHit
                        ? 0xFF55FF55
                        : 0xFFFF5555;

        accentColor = applyAlpha(accentColor, alpha);

        int accentX = boxX + 2;
        int accentY = boxY + boxHeight - 1;
        int accentWidth = boxWidth - 4;

        graphics.method_25294(
                accentX,
                accentY,
                accentX + accentWidth,
                accentY + 1,
                accentColor
        );

        int indicatorColor =
                applyAlpha(targetNameColor, alpha);

        int indicatorSize = 3;

        int indicatorX = targetX - 6;
        int indicatorY = targetY + 4;

        graphics.method_25294(
                indicatorX,
                indicatorY,
                indicatorX + indicatorSize,
                indicatorY + indicatorSize,
                indicatorColor
        );

        drawText(
                graphics,
                client,
                targetName,
                targetX,
                targetY,
                fadedTargetColor,
                alpha
        );

        drawText(
                graphics,
                client,
                aimLabel,
                aimX,
                aimY,
                fadedLabelColor,
                alpha
        );

        drawText(
                graphics,
                client,
                distanceText,
                aimX + aimLabelWidth,
                aimY,
                fadedDistanceColor,
                alpha
        );
    }

    private static void renderCachedHud(
            class_332 graphics,
            class_310 client
    ) {
        if (hudAlpha <= 0.001) {
            return;
        }

        if (!cachedProjectileTargetName.isEmpty()) {
            renderProjectileHudContent(
                    graphics,
                    client,
                    cachedProjectileTargetName,
                    "Aim: ",
                    cachedProjectileDistanceText,
                    cachedProjectileWillHit,
                    cachedProjectileTargetColor,
                    hudAlpha
            );

            return;
        }

        if (!cachedMeleeTargetName.isEmpty()) {
            renderMeleeHud(
                    graphics,
                    client,
                    cachedMeleeTargetName,
                    "Reach: ",
                    cachedMeleeDistanceText,
                    cachedMeleeWithinReach,
                    cachedMeleeTargetColor,
                    hudAlpha
            );
        }
    }

    private static void drawRoundedBox(
            class_332 graphics,
            int x,
            int y,
            int width,
            int height,
            int color
    ) {
        if (width <= 2 || height <= 2) {
            graphics.method_25294(
                    x,
                    y,
                    x + width,
                    y + height,
                    color
            );

            return;
        }

        graphics.method_25294(
                x + 1,
                y,
                x + width - 1,
                y + height,
                color
        );

        graphics.method_25294(
                x,
                y + 1,
                x + width,
                y + height - 1,
                color
        );
    }

    private static void drawText(
            class_332 graphics,
            class_310 client,
            String text,
            int x,
            int y,
            int color,
            double alpha
    ) {
        class_2561 component =
                class_2561.method_43470(text);

        int shadowColor =
                applyAlpha(0xAA000000, alpha);

        graphics.method_27535(
                client.field_1772,
                component,
                x + 1,
                y + 1,
                shadowColor
        );

        graphics.method_27535(
                client.field_1772,
                component,
                x,
                y,
                color
        );
    }

    private static int getTargetNameColor(class_1297 target) {
        if (target instanceof class_1657
                || target instanceof class_1569) {

            return 0xFFFF5555;
        }

        return 0xFF55FF55;
    }

    private static int applyAlpha(
            int color,
            double alpha
    ) {
        alpha = Math.max(
                0.0,
                Math.min(1.0, alpha)
        );

        int originalAlpha =
                (color >>> 24) & 0xFF;

        int finalAlpha =
                (int) (originalAlpha * alpha);

        return (color & 0x00FFFFFF)
                | (finalAlpha << 24);
    }

    private static void updateHudAlpha(
            boolean visible
    ) {
        double targetAlpha =
                visible ? 1.0 : 0.0;

        double difference =
                targetAlpha - hudAlpha;

        hudAlpha +=
                difference * FADE_SPEED;

        if (Math.abs(difference) < 0.005) {
            hudAlpha = targetAlpha;
        }
    }

    private static void updateSmoothedDistance(
            class_1297 target,
            double actualDistance
    ) {
        if (lastTarget != target
                || displayedDistance < 0) {

            lastTarget = target;
            displayedDistance = actualDistance;
            return;
        }

        displayedDistance +=
                (actualDistance - displayedDistance)
                        * SMOOTH_SPEED;

        if (Math.abs(
                actualDistance - displayedDistance
        ) < 0.005) {

            displayedDistance = actualDistance;
        }
    }

    private static void updateSmoothedProjectileDistance(
            class_1297 target,
            double actualDistance
    ) {
        if (lastProjectileTarget != target
                || displayedProjectileDistance < 0) {

            lastProjectileTarget = target;
            displayedProjectileDistance = actualDistance;
            return;
        }

        displayedProjectileDistance +=
                (actualDistance - displayedProjectileDistance)
                        * SMOOTH_SPEED;

        if (Math.abs(
                actualDistance - displayedProjectileDistance
        ) < 0.005) {

            displayedProjectileDistance = actualDistance;
        }
    }

    private static void resetSmoothing() {
        lastTarget = null;
        displayedDistance = -1.0;

        resetProjectileSmoothing();

        cachedMeleeTargetName = "";
        cachedMeleeDistanceText = "";

        cachedProjectileTargetName = "";
        cachedProjectileDistanceText = "";

        hudAlpha = 0.0;
    }

    private static void resetSmoothingValuesOnly() {
        resetMeleeSmoothingOnly();
        resetProjectileSmoothing();
    }

    private static void resetMeleeSmoothingOnly() {
        lastTarget = null;
        displayedDistance = -1.0;
    }

    private static void resetProjectileSmoothing() {
        lastProjectileTarget = null;
        displayedProjectileDistance = -1.0;
    }

    private static void renderNotification(
            class_332 graphics,
            class_310 client
    ) {
        if (!ReachHudNotification.isVisible()) {
            return;
        }

        String text =
                ReachHudNotification.isEnabled()
                        ? "ReachHUD: Active"
                        : "ReachHUD: Inactive";

        int screenWidth =
                client.method_22683().method_4486();

        int screenHeight =
                client.method_22683().method_4502();

        int textWidth =
                client.field_1772.method_1727(text);

        int x =
                (screenWidth - textWidth) / 2;

        int y =
                screenHeight - 58;

        int textColor =
                ReachHudNotification.isEnabled()
                        ? 0xFF55FF55
                        : 0xFFFF5555;

        drawText(
                graphics,
                client,
                text,
                x,
                y,
                textColor,
                1.0
        );
    }
}