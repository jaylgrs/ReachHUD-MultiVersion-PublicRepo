package main.reachhud.projectile;

import net.minecraft.class_238;
import net.minecraft.class_243;

public final class ProjectilePhysics {

    private static final double MAX_DISTANCE = 64.0;

    /*
     * Vanilla arrow-style physics.
     *
     * Minecraft projectile movement is simulated once per tick.
     */
    private static final double ARROW_GRAVITY = 0.05;
    private static final double AIR_INERTIA = 0.99;

    /*
     * Small projectile collision box.
     *
     * The actual arrow entity is very small, so this keeps
     * the simulation from producing obviously false hits.
     */
    private static final double PROJECTILE_HALF_SIZE = 0.125;

    private ProjectilePhysics() {
    }

    public static TrajectoryResult simulate(
            class_243 startPosition,
            class_243 initialVelocity,
            class_238 targetBox
    ) {
        if (startPosition == null
                || initialVelocity == null
                || targetBox == null) {
            return TrajectoryResult.miss();
        }

        class_243 position = startPosition;
        class_243 velocity = initialVelocity;

        double travelledDistance = 0.0;

        /*
         * Simulate one Minecraft tick at a time.
         *
         * We use a maximum distance rather than a fixed number
         * of ticks because projectile speed changes depending
         * on the weapon charge.
         */
        for (int tick = 0; tick < 200; tick++) {

            class_243 nextPosition = position.method_1019(velocity);

            /*
             * Check the complete movement segment rather than
             * only checking the projectile at the final point.
             *
             * This prevents fast arrows from passing through
             * thin parts of an entity between ticks.
             */
            if (segmentIntersectsTarget(
                    position,
                    nextPosition,
                    targetBox
            )) {
                double hitDistance =
                        travelledDistance
                                + position.method_1022(nextPosition);

                return TrajectoryResult.hit(
                        nextPosition,
                        hitDistance
                );
            }

            travelledDistance +=
                    position.method_1022(nextPosition);

            if (travelledDistance >= MAX_DISTANCE) {
                break;
            }

            position = nextPosition;

            /*
             * Vanilla-style arrow movement:
             *
             * 1. Apply air inertia to the velocity.
             * 2. Apply gravity to the vertical velocity.
             *
             * This is deliberately tick-based.
             */
            velocity = new class_243(
                    velocity.field_1352 * AIR_INERTIA,
                    velocity.field_1351 * AIR_INERTIA
                            - ARROW_GRAVITY,
                    velocity.field_1350 * AIR_INERTIA
            );
        }

        return TrajectoryResult.miss();
    }

    private static boolean segmentIntersectsTarget(
            class_243 start,
            class_243 end,
            class_238 targetBox
    ) {
        /*
         * Expand the target slightly by the projectile radius.
         *
         * This approximates the collision volume of the arrow.
         */
        class_238 expandedTarget = targetBox.method_1014(
                PROJECTILE_HALF_SIZE
        );

        return expandedTarget
                .method_992(start, end)
                .isPresent();
    }

    public record TrajectoryResult(
            boolean hit,
            class_243 hitPosition,
            double distance
    ) {

        public static TrajectoryResult hit(
                class_243 hitPosition,
                double distance
        ) {
            return new TrajectoryResult(
                    true,
                    hitPosition,
                    distance
            );
        }

        public static TrajectoryResult miss() {
            return new TrajectoryResult(
                    false,
                    class_243.field_1353,
                    -1.0
            );
        }
    }
}