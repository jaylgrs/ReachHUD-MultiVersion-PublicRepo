package main.reachhud.projectile;

import net.minecraft.class_238;
import net.minecraft.class_243;

public final class FireworkPhysics {

    private static final double MAX_DISTANCE = 128.0;

    /*
     * Vanilla firework rocket movement.
     *
     * Each tick:
     *
     * horizontal velocity *= 1.15
     * vertical velocity += 0.04
     */
    private static final double HORIZONTAL_ACCELERATION = 1.15;
    private static final double VERTICAL_ACCELERATION = 0.04;

    /*
     * Small collision volume for the rocket.
     */
    private static final double PROJECTILE_HALF_SIZE = 0.125;

    private FireworkPhysics() {
    }

    public static TrajectoryResult simulate(
            class_243 startPosition,
            class_243 initialVelocity,
            class_238 targetBox
    ) {
        if (startPosition == null
                || initialVelocity == null
                || targetBox == null) {
            return TrajectoryResult.miss();
        }

        class_243 position = startPosition;
        class_243 velocity = initialVelocity;

        double travelledDistance = 0.0;

        /*
         * Fireworks have a finite lifetime in vanilla,
         * but 200 ticks is a safe prediction limit.
         */
        for (int tick = 0; tick < 200; tick++) {

            class_243 nextPosition =
                    position.method_1019(velocity);

            /*
             * Check the complete movement segment.
             *
             * This prevents a fast-moving rocket from
             * skipping through an entity between ticks.
             */
            if (segmentIntersectsTarget(
                    position,
                    nextPosition,
                    targetBox
            )) {
                double hitDistance =
                        travelledDistance
                                + position.method_1022(nextPosition);

                return TrajectoryResult.hit(
                        nextPosition,
                        hitDistance
                );
            }

            travelledDistance +=
                    position.method_1022(nextPosition);

            if (travelledDistance >= MAX_DISTANCE) {
                break;
            }

            position = nextPosition;

            /*
             * Vanilla FireworkRocketEntity movement:
             *
             * X/Z velocity gets multiplied by 1.15.
             * Y velocity receives +0.04.
             */
            velocity = new class_243(
                    velocity.field_1352 * HORIZONTAL_ACCELERATION,
                    velocity.field_1351 + VERTICAL_ACCELERATION,
                    velocity.field_1350 * HORIZONTAL_ACCELERATION
            );
        }

        return TrajectoryResult.miss();
    }

    private static boolean segmentIntersectsTarget(
            class_243 start,
            class_243 end,
            class_238 targetBox
    ) {
        class_238 expandedTarget =
                targetBox.method_1014(
                        PROJECTILE_HALF_SIZE
                );

        return expandedTarget
                .method_992(start, end)
                .isPresent();
    }

    public record TrajectoryResult(
            boolean hit,
            class_243 hitPosition,
            double distance
    ) {

        public static TrajectoryResult hit(
                class_243 hitPosition,
                double distance
        ) {
            return new TrajectoryResult(
                    true,
                    hitPosition,
                    distance
            );
        }

        public static TrajectoryResult miss() {
            return new TrajectoryResult(
                    false,
                    class_243.field_1353,
                    -1.0
            );
        }
    }
}